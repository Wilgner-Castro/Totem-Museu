﻿namespace Museu_Pim.Formularios
{
    partial class Login
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            chn_CapsLock = new CheckBox();
            Chn_Shift = new CheckBox();
            Btn_Sair = new Button();
            Btn_Tres = new Button();
            Btn_PontoDir = new Button();
            Btn_Seis = new Button();
            Btn_Soma = new Button();
            Btn_Nove = new Button();
            Btn_Menos = new Button();
            Btn_Multiplicar = new Button();
            Btn_Dois = new Button();
            Btn_Um = new Button();
            Btn_Zero = new Button();
            Btn_VirgulaDir = new Button();
            button53 = new Button();
            Btn_PontoVirgila = new Button();
            Btn_Ponto = new Button();
            Btn_Virgula = new Button();
            Btn_M = new Button();
            Btn_N = new Button();
            Btn_B = new Button();
            Btn_V = new Button();
            Btn_C = new Button();
            Btn_X = new Button();
            Btn_Z = new Button();
            Btn_Cinco = new Button();
            Btn_Quatro = new Button();
            Btn_Salvar = new Button();
            Btn_Interogacao = new Button();
            Btn_ChapeueCobra = new Button();
            Btn_Ç = new Button();
            Btn_L = new Button();
            Btn_K = new Button();
            Btn_J = new Button();
            Btn_H = new Button();
            Btn_G = new Button();
            Btn_F = new Button();
            Btn_D = new Button();
            Btn_S = new Button();
            Btn_A = new Button();
            Btn_Oito = new Button();
            Btn_Sete = new Button();
            Btn_Backspage = new Button();
            Btn_AbreChaves = new Button();
            Btn_AssentoS = new Button();
            Btn_P = new Button();
            Btn_O = new Button();
            Btn_I = new Button();
            Btn_U = new Button();
            Btn_Y = new Button();
            Btn_T = new Button();
            Btn_R = new Button();
            Btn_E = new Button();
            Btn_W = new Button();
            Btn_Q = new Button();
            Btn_Dividir = new Button();
            Btn_FechsChaves = new Button();
            Btn_MaisIgual = new Button();
            btn_UnderlaineeMenos = new Button();
            btn_FechaParetenses = new Button();
            btn_AbriParetenses = new Button();
            btn_Asteristico = new Button();
            btn_Ecomercial = new Button();
            btn_doispontoscima = new Button();
            btn_Porcetagem = new Button();
            btn_sifrao = new Button();
            btn_hastag = new Button();
            btn_Arroba = new Button();
            btn_esclamacao = new Button();
            btn_Aspas = new Button();
            label3 = new Label();
            txt_Senha_login = new TextBox();
            label1 = new Label();
            lbl_Nome = new Label();
            txb_Nome_login = new TextBox();
            Btn_Cadastro = new Button();
            pictureBox1 = new PictureBox();
            Btn_Entrar = new Button();
            Btn_IrCadastro = new Button();
            Btn_IrHome = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // chn_CapsLock
            // 
            chn_CapsLock.Appearance = Appearance.Button;
            chn_CapsLock.BackColor = SystemColors.ButtonShadow;
            chn_CapsLock.Location = new Point(42, 693);
            chn_CapsLock.Margin = new Padding(3, 4, 3, 4);
            chn_CapsLock.Name = "chn_CapsLock";
            chn_CapsLock.Size = new Size(86, 67);
            chn_CapsLock.TabIndex = 154;
            chn_CapsLock.Text = "Caps Lock";
            chn_CapsLock.UseVisualStyleBackColor = false;
            chn_CapsLock.CheckedChanged += chn_CapsLock_CheckedChanged;
            // 
            // Chn_Shift
            // 
            Chn_Shift.Appearance = Appearance.Button;
            Chn_Shift.BackColor = SystemColors.ButtonShadow;
            Chn_Shift.Location = new Point(42, 768);
            Chn_Shift.Margin = new Padding(3, 4, 3, 4);
            Chn_Shift.Name = "Chn_Shift";
            Chn_Shift.Size = new Size(86, 67);
            Chn_Shift.TabIndex = 153;
            Chn_Shift.Text = "Shift";
            Chn_Shift.UseVisualStyleBackColor = false;
            Chn_Shift.CheckedChanged += Chn_Shift_CheckedChanged;
            // 
            // Btn_Sair
            // 
            Btn_Sair.Location = new Point(1758, 596);
            Btn_Sair.Margin = new Padding(3, 4, 3, 4);
            Btn_Sair.Name = "Btn_Sair";
            Btn_Sair.Size = new Size(96, 108);
            Btn_Sair.TabIndex = 152;
            Btn_Sair.Text = "Sair";
            Btn_Sair.UseVisualStyleBackColor = true;
            Btn_Sair.Click += Btn_Sair_Click;
            // 
            // Btn_Tres
            // 
            Btn_Tres.BackColor = SystemColors.ButtonShadow;
            Btn_Tres.Location = new Point(1337, 768);
            Btn_Tres.Margin = new Padding(3, 4, 3, 4);
            Btn_Tres.Name = "Btn_Tres";
            Btn_Tres.Size = new Size(86, 67);
            Btn_Tres.TabIndex = 151;
            Btn_Tres.Text = "3";
            Btn_Tres.UseVisualStyleBackColor = false;
            Btn_Tres.Click += Btn_Tres_Click;
            // 
            // Btn_PontoDir
            // 
            Btn_PontoDir.BackColor = SystemColors.ButtonShadow;
            Btn_PontoDir.Location = new Point(970, 843);
            Btn_PontoDir.Margin = new Padding(3, 4, 3, 4);
            Btn_PontoDir.Name = "Btn_PontoDir";
            Btn_PontoDir.Size = new Size(86, 67);
            Btn_PontoDir.TabIndex = 150;
            Btn_PontoDir.Text = ".";
            Btn_PontoDir.UseVisualStyleBackColor = false;
            Btn_PontoDir.Click += Btn_PontoDir_Click;
            // 
            // Btn_Seis
            // 
            Btn_Seis.BackColor = SystemColors.ButtonShadow;
            Btn_Seis.Location = new Point(1337, 693);
            Btn_Seis.Margin = new Padding(3, 4, 3, 4);
            Btn_Seis.Name = "Btn_Seis";
            Btn_Seis.Size = new Size(86, 67);
            Btn_Seis.TabIndex = 149;
            Btn_Seis.Text = "6";
            Btn_Seis.UseVisualStyleBackColor = false;
            Btn_Seis.Click += Btn_Seis_Click;
            // 
            // Btn_Soma
            // 
            Btn_Soma.BackColor = SystemColors.ButtonShadow;
            Btn_Soma.Location = new Point(1063, 843);
            Btn_Soma.Margin = new Padding(3, 4, 3, 4);
            Btn_Soma.Name = "Btn_Soma";
            Btn_Soma.Size = new Size(86, 67);
            Btn_Soma.TabIndex = 148;
            Btn_Soma.Text = "+";
            Btn_Soma.UseVisualStyleBackColor = false;
            Btn_Soma.Click += Btn_Soma_Click;
            // 
            // Btn_Nove
            // 
            Btn_Nove.BackColor = SystemColors.ButtonShadow;
            Btn_Nove.Location = new Point(1337, 619);
            Btn_Nove.Margin = new Padding(3, 4, 3, 4);
            Btn_Nove.Name = "Btn_Nove";
            Btn_Nove.Size = new Size(86, 67);
            Btn_Nove.TabIndex = 147;
            Btn_Nove.Text = "9";
            Btn_Nove.UseVisualStyleBackColor = false;
            Btn_Nove.Click += Btn_Nove_Click;
            // 
            // Btn_Menos
            // 
            Btn_Menos.BackColor = SystemColors.ButtonShadow;
            Btn_Menos.Location = new Point(600, 843);
            Btn_Menos.Margin = new Padding(3, 4, 3, 4);
            Btn_Menos.Name = "Btn_Menos";
            Btn_Menos.Size = new Size(86, 67);
            Btn_Menos.TabIndex = 146;
            Btn_Menos.Text = "-";
            Btn_Menos.UseVisualStyleBackColor = false;
            Btn_Menos.Click += Btn_Menos_Click;
            // 
            // Btn_Multiplicar
            // 
            Btn_Multiplicar.BackColor = SystemColors.ButtonShadow;
            Btn_Multiplicar.Location = new Point(878, 843);
            Btn_Multiplicar.Margin = new Padding(3, 4, 3, 4);
            Btn_Multiplicar.Name = "Btn_Multiplicar";
            Btn_Multiplicar.Size = new Size(86, 67);
            Btn_Multiplicar.TabIndex = 145;
            Btn_Multiplicar.Text = "*";
            Btn_Multiplicar.UseVisualStyleBackColor = false;
            Btn_Multiplicar.Click += Btn_Multiplicar_Click;
            // 
            // Btn_Dois
            // 
            Btn_Dois.BackColor = SystemColors.ButtonShadow;
            Btn_Dois.Location = new Point(1246, 768);
            Btn_Dois.Margin = new Padding(3, 4, 3, 4);
            Btn_Dois.Name = "Btn_Dois";
            Btn_Dois.Size = new Size(86, 67);
            Btn_Dois.TabIndex = 144;
            Btn_Dois.Text = "2";
            Btn_Dois.UseVisualStyleBackColor = false;
            Btn_Dois.Click += Btn_Dois_Click;
            // 
            // Btn_Um
            // 
            Btn_Um.BackColor = SystemColors.ButtonShadow;
            Btn_Um.Location = new Point(1153, 768);
            Btn_Um.Margin = new Padding(3, 4, 3, 4);
            Btn_Um.Name = "Btn_Um";
            Btn_Um.Size = new Size(86, 67);
            Btn_Um.TabIndex = 143;
            Btn_Um.Text = "1";
            Btn_Um.UseVisualStyleBackColor = false;
            Btn_Um.Click += Btn_Um_Click;
            // 
            // Btn_Zero
            // 
            Btn_Zero.BackColor = SystemColors.ButtonShadow;
            Btn_Zero.Location = new Point(1153, 843);
            Btn_Zero.Margin = new Padding(3, 4, 3, 4);
            Btn_Zero.Name = "Btn_Zero";
            Btn_Zero.Size = new Size(177, 67);
            Btn_Zero.TabIndex = 142;
            Btn_Zero.Text = "0";
            Btn_Zero.UseVisualStyleBackColor = false;
            Btn_Zero.Click += Btn_Zero_Click;
            // 
            // Btn_VirgulaDir
            // 
            Btn_VirgulaDir.BackColor = SystemColors.ButtonShadow;
            Btn_VirgulaDir.Location = new Point(1337, 843);
            Btn_VirgulaDir.Margin = new Padding(3, 4, 3, 4);
            Btn_VirgulaDir.Name = "Btn_VirgulaDir";
            Btn_VirgulaDir.Size = new Size(86, 67);
            Btn_VirgulaDir.TabIndex = 141;
            Btn_VirgulaDir.Text = ",";
            Btn_VirgulaDir.UseVisualStyleBackColor = false;
            Btn_VirgulaDir.Click += Btn_VirgulaDir_Click;
            // 
            // button53
            // 
            button53.BackColor = SystemColors.ButtonShadow;
            button53.Location = new Point(42, 843);
            button53.Margin = new Padding(3, 4, 3, 4);
            button53.Name = "button53";
            button53.Size = new Size(551, 67);
            button53.TabIndex = 140;
            button53.Text = "Space";
            button53.UseVisualStyleBackColor = false;
            button53.Click += button53_Click;
            // 
            // Btn_PontoVirgila
            // 
            Btn_PontoVirgila.BackColor = SystemColors.ButtonShadow;
            Btn_PontoVirgila.Location = new Point(1061, 619);
            Btn_PontoVirgila.Margin = new Padding(3, 4, 3, 4);
            Btn_PontoVirgila.Name = "Btn_PontoVirgila";
            Btn_PontoVirgila.Size = new Size(86, 67);
            Btn_PontoVirgila.TabIndex = 139;
            Btn_PontoVirgila.Text = ":\r\n;";
            Btn_PontoVirgila.UseVisualStyleBackColor = false;
            Btn_PontoVirgila.Click += Btn_PontoVirgila_Click;
            // 
            // Btn_Ponto
            // 
            Btn_Ponto.BackColor = SystemColors.ButtonShadow;
            Btn_Ponto.Location = new Point(968, 619);
            Btn_Ponto.Margin = new Padding(3, 4, 3, 4);
            Btn_Ponto.Name = "Btn_Ponto";
            Btn_Ponto.Size = new Size(86, 67);
            Btn_Ponto.TabIndex = 138;
            Btn_Ponto.Text = ">\r\n.";
            Btn_Ponto.UseVisualStyleBackColor = false;
            Btn_Ponto.Click += Btn_Ponto_Click;
            // 
            // Btn_Virgula
            // 
            Btn_Virgula.BackColor = SystemColors.ButtonShadow;
            Btn_Virgula.Location = new Point(968, 693);
            Btn_Virgula.Margin = new Padding(3, 4, 3, 4);
            Btn_Virgula.Name = "Btn_Virgula";
            Btn_Virgula.Size = new Size(86, 67);
            Btn_Virgula.TabIndex = 137;
            Btn_Virgula.Text = "<\r\n,";
            Btn_Virgula.UseVisualStyleBackColor = false;
            Btn_Virgula.Click += Btn_Virgula_Click;
            // 
            // Btn_M
            // 
            Btn_M.BackColor = SystemColors.ButtonShadow;
            Btn_M.Location = new Point(690, 768);
            Btn_M.Margin = new Padding(3, 4, 3, 4);
            Btn_M.Name = "Btn_M";
            Btn_M.Size = new Size(86, 67);
            Btn_M.TabIndex = 136;
            Btn_M.Text = "M";
            Btn_M.UseVisualStyleBackColor = false;
            Btn_M.Click += Btn_M_Click;
            // 
            // Btn_N
            // 
            Btn_N.BackColor = SystemColors.ButtonShadow;
            Btn_N.Location = new Point(598, 768);
            Btn_N.Margin = new Padding(3, 4, 3, 4);
            Btn_N.Name = "Btn_N";
            Btn_N.Size = new Size(86, 67);
            Btn_N.TabIndex = 135;
            Btn_N.Text = "N";
            Btn_N.UseVisualStyleBackColor = false;
            Btn_N.Click += Btn_N_Click;
            // 
            // Btn_B
            // 
            Btn_B.BackColor = SystemColors.ButtonShadow;
            Btn_B.Location = new Point(505, 768);
            Btn_B.Margin = new Padding(3, 4, 3, 4);
            Btn_B.Name = "Btn_B";
            Btn_B.Size = new Size(86, 67);
            Btn_B.TabIndex = 134;
            Btn_B.Text = "B";
            Btn_B.UseVisualStyleBackColor = false;
            Btn_B.Click += Btn_B_Click;
            // 
            // Btn_V
            // 
            Btn_V.BackColor = SystemColors.ButtonShadow;
            Btn_V.Location = new Point(413, 768);
            Btn_V.Margin = new Padding(3, 4, 3, 4);
            Btn_V.Name = "Btn_V";
            Btn_V.Size = new Size(86, 67);
            Btn_V.TabIndex = 133;
            Btn_V.Text = "V";
            Btn_V.UseVisualStyleBackColor = false;
            Btn_V.Click += Btn_V_Click;
            // 
            // Btn_C
            // 
            Btn_C.BackColor = SystemColors.ButtonShadow;
            Btn_C.Location = new Point(320, 768);
            Btn_C.Margin = new Padding(3, 4, 3, 4);
            Btn_C.Name = "Btn_C";
            Btn_C.Size = new Size(86, 67);
            Btn_C.TabIndex = 132;
            Btn_C.Text = "C";
            Btn_C.UseVisualStyleBackColor = false;
            Btn_C.Click += Btn_C_Click;
            // 
            // Btn_X
            // 
            Btn_X.BackColor = SystemColors.ButtonShadow;
            Btn_X.Location = new Point(227, 768);
            Btn_X.Margin = new Padding(3, 4, 3, 4);
            Btn_X.Name = "Btn_X";
            Btn_X.Size = new Size(86, 67);
            Btn_X.TabIndex = 131;
            Btn_X.Text = "X";
            Btn_X.UseVisualStyleBackColor = false;
            Btn_X.Click += Btn_X_Click;
            // 
            // Btn_Z
            // 
            Btn_Z.BackColor = SystemColors.ButtonShadow;
            Btn_Z.Location = new Point(135, 768);
            Btn_Z.Margin = new Padding(3, 4, 3, 4);
            Btn_Z.Name = "Btn_Z";
            Btn_Z.Size = new Size(86, 67);
            Btn_Z.TabIndex = 130;
            Btn_Z.Text = "Z";
            Btn_Z.UseVisualStyleBackColor = false;
            Btn_Z.Click += Btn_Z_Click;
            // 
            // Btn_Cinco
            // 
            Btn_Cinco.BackColor = SystemColors.ButtonShadow;
            Btn_Cinco.Location = new Point(1246, 693);
            Btn_Cinco.Margin = new Padding(3, 4, 3, 4);
            Btn_Cinco.Name = "Btn_Cinco";
            Btn_Cinco.Size = new Size(86, 67);
            Btn_Cinco.TabIndex = 129;
            Btn_Cinco.Text = "5";
            Btn_Cinco.UseVisualStyleBackColor = false;
            Btn_Cinco.Click += Btn_Cinco_Click;
            // 
            // Btn_Quatro
            // 
            Btn_Quatro.BackColor = SystemColors.ButtonShadow;
            Btn_Quatro.Location = new Point(1153, 693);
            Btn_Quatro.Margin = new Padding(3, 4, 3, 4);
            Btn_Quatro.Name = "Btn_Quatro";
            Btn_Quatro.Size = new Size(86, 67);
            Btn_Quatro.TabIndex = 128;
            Btn_Quatro.Text = "4";
            Btn_Quatro.UseVisualStyleBackColor = false;
            Btn_Quatro.Click += Btn_Quatro_Click;
            // 
            // Btn_Salvar
            // 
            Btn_Salvar.Location = new Point(1758, 477);
            Btn_Salvar.Margin = new Padding(3, 4, 3, 4);
            Btn_Salvar.Name = "Btn_Salvar";
            Btn_Salvar.Size = new Size(96, 111);
            Btn_Salvar.TabIndex = 127;
            Btn_Salvar.Text = "Salvar";
            Btn_Salvar.UseVisualStyleBackColor = true;
            Btn_Salvar.Click += Btn_Salvar_Click;
            // 
            // Btn_Interogacao
            // 
            Btn_Interogacao.BackColor = SystemColors.ButtonShadow;
            Btn_Interogacao.Location = new Point(875, 768);
            Btn_Interogacao.Margin = new Padding(3, 4, 3, 4);
            Btn_Interogacao.Name = "Btn_Interogacao";
            Btn_Interogacao.Size = new Size(86, 67);
            Btn_Interogacao.TabIndex = 126;
            Btn_Interogacao.Text = "?\r\n/";
            Btn_Interogacao.UseVisualStyleBackColor = false;
            Btn_Interogacao.Click += Btn_Interogacao_Click;
            // 
            // Btn_ChapeueCobra
            // 
            Btn_ChapeueCobra.BackColor = SystemColors.ButtonShadow;
            Btn_ChapeueCobra.Location = new Point(968, 768);
            Btn_ChapeueCobra.Margin = new Padding(3, 4, 3, 4);
            Btn_ChapeueCobra.Name = "Btn_ChapeueCobra";
            Btn_ChapeueCobra.Size = new Size(86, 67);
            Btn_ChapeueCobra.TabIndex = 125;
            Btn_ChapeueCobra.Text = "^\r\n~\r\n";
            Btn_ChapeueCobra.UseVisualStyleBackColor = false;
            Btn_ChapeueCobra.Click += Btn_ChapeueCobra_Click;
            // 
            // Btn_Ç
            // 
            Btn_Ç.BackColor = SystemColors.ButtonShadow;
            Btn_Ç.Location = new Point(783, 768);
            Btn_Ç.Margin = new Padding(3, 4, 3, 4);
            Btn_Ç.Name = "Btn_Ç";
            Btn_Ç.Size = new Size(86, 67);
            Btn_Ç.TabIndex = 124;
            Btn_Ç.Text = "Ç";
            Btn_Ç.UseVisualStyleBackColor = false;
            Btn_Ç.Click += Btn_Ç_Click;
            // 
            // Btn_L
            // 
            Btn_L.BackColor = SystemColors.ButtonShadow;
            Btn_L.Location = new Point(875, 693);
            Btn_L.Margin = new Padding(3, 4, 3, 4);
            Btn_L.Name = "Btn_L";
            Btn_L.Size = new Size(86, 67);
            Btn_L.TabIndex = 123;
            Btn_L.Text = "L";
            Btn_L.UseVisualStyleBackColor = false;
            Btn_L.Click += Btn_L_Click;
            // 
            // Btn_K
            // 
            Btn_K.BackColor = SystemColors.ButtonShadow;
            Btn_K.Location = new Point(783, 693);
            Btn_K.Margin = new Padding(3, 4, 3, 4);
            Btn_K.Name = "Btn_K";
            Btn_K.Size = new Size(86, 67);
            Btn_K.TabIndex = 122;
            Btn_K.Text = "K";
            Btn_K.UseVisualStyleBackColor = false;
            Btn_K.Click += Btn_K_Click;
            // 
            // Btn_J
            // 
            Btn_J.BackColor = SystemColors.ButtonShadow;
            Btn_J.Location = new Point(690, 693);
            Btn_J.Margin = new Padding(3, 4, 3, 4);
            Btn_J.Name = "Btn_J";
            Btn_J.Size = new Size(86, 67);
            Btn_J.TabIndex = 121;
            Btn_J.Text = "J";
            Btn_J.UseVisualStyleBackColor = false;
            Btn_J.Click += Btn_J_Click;
            // 
            // Btn_H
            // 
            Btn_H.BackColor = SystemColors.ButtonShadow;
            Btn_H.Location = new Point(598, 693);
            Btn_H.Margin = new Padding(3, 4, 3, 4);
            Btn_H.Name = "Btn_H";
            Btn_H.Size = new Size(86, 67);
            Btn_H.TabIndex = 120;
            Btn_H.Text = "H";
            Btn_H.UseVisualStyleBackColor = false;
            Btn_H.Click += Btn_H_Click;
            // 
            // Btn_G
            // 
            Btn_G.BackColor = SystemColors.ButtonShadow;
            Btn_G.Location = new Point(505, 693);
            Btn_G.Margin = new Padding(3, 4, 3, 4);
            Btn_G.Name = "Btn_G";
            Btn_G.Size = new Size(86, 67);
            Btn_G.TabIndex = 119;
            Btn_G.Text = "G";
            Btn_G.UseVisualStyleBackColor = false;
            Btn_G.Click += Btn_G_Click;
            // 
            // Btn_F
            // 
            Btn_F.BackColor = SystemColors.ButtonShadow;
            Btn_F.Location = new Point(413, 693);
            Btn_F.Margin = new Padding(3, 4, 3, 4);
            Btn_F.Name = "Btn_F";
            Btn_F.Size = new Size(86, 67);
            Btn_F.TabIndex = 118;
            Btn_F.Text = "F";
            Btn_F.UseVisualStyleBackColor = false;
            Btn_F.Click += Btn_F_Click;
            // 
            // Btn_D
            // 
            Btn_D.BackColor = SystemColors.ButtonShadow;
            Btn_D.Location = new Point(320, 693);
            Btn_D.Margin = new Padding(3, 4, 3, 4);
            Btn_D.Name = "Btn_D";
            Btn_D.Size = new Size(86, 67);
            Btn_D.TabIndex = 117;
            Btn_D.Text = "D";
            Btn_D.UseVisualStyleBackColor = false;
            Btn_D.Click += Btn_D_Click;
            // 
            // Btn_S
            // 
            Btn_S.BackColor = SystemColors.ButtonShadow;
            Btn_S.Location = new Point(227, 693);
            Btn_S.Margin = new Padding(3, 4, 3, 4);
            Btn_S.Name = "Btn_S";
            Btn_S.Size = new Size(86, 67);
            Btn_S.TabIndex = 116;
            Btn_S.Text = "S";
            Btn_S.UseVisualStyleBackColor = false;
            Btn_S.Click += Btn_S_Click;
            // 
            // Btn_A
            // 
            Btn_A.BackColor = SystemColors.ButtonShadow;
            Btn_A.Location = new Point(135, 693);
            Btn_A.Margin = new Padding(3, 4, 3, 4);
            Btn_A.Name = "Btn_A";
            Btn_A.Size = new Size(86, 67);
            Btn_A.TabIndex = 115;
            Btn_A.Text = "A";
            Btn_A.UseVisualStyleBackColor = false;
            Btn_A.Click += Btn_A_Click;
            // 
            // Btn_Oito
            // 
            Btn_Oito.BackColor = SystemColors.ButtonShadow;
            Btn_Oito.Location = new Point(1246, 619);
            Btn_Oito.Margin = new Padding(3, 4, 3, 4);
            Btn_Oito.Name = "Btn_Oito";
            Btn_Oito.Size = new Size(86, 67);
            Btn_Oito.TabIndex = 114;
            Btn_Oito.Text = "8";
            Btn_Oito.UseVisualStyleBackColor = false;
            Btn_Oito.Click += Btn_Oito_Click;
            // 
            // Btn_Sete
            // 
            Btn_Sete.BackColor = SystemColors.ButtonShadow;
            Btn_Sete.Location = new Point(1153, 619);
            Btn_Sete.Margin = new Padding(3, 4, 3, 4);
            Btn_Sete.Name = "Btn_Sete";
            Btn_Sete.Size = new Size(86, 67);
            Btn_Sete.TabIndex = 113;
            Btn_Sete.Text = "7";
            Btn_Sete.UseVisualStyleBackColor = false;
            Btn_Sete.Click += Btn_Sete_Click;
            // 
            // Btn_Backspage
            // 
            Btn_Backspage.BackColor = SystemColors.ButtonShadow;
            Btn_Backspage.Location = new Point(875, 544);
            Btn_Backspage.Margin = new Padding(3, 4, 3, 4);
            Btn_Backspage.Name = "Btn_Backspage";
            Btn_Backspage.Size = new Size(178, 67);
            Btn_Backspage.TabIndex = 112;
            Btn_Backspage.Text = "Backspace";
            Btn_Backspage.UseVisualStyleBackColor = false;
            Btn_Backspage.Click += Btn_Backspage_Click;
            // 
            // Btn_AbreChaves
            // 
            Btn_AbreChaves.BackColor = SystemColors.ButtonShadow;
            Btn_AbreChaves.Location = new Point(1245, 544);
            Btn_AbreChaves.Margin = new Padding(3, 4, 3, 4);
            Btn_AbreChaves.Name = "Btn_AbreChaves";
            Btn_AbreChaves.Size = new Size(86, 67);
            Btn_AbreChaves.TabIndex = 111;
            Btn_AbreChaves.Text = "{\r\n[\r\n";
            Btn_AbreChaves.UseVisualStyleBackColor = false;
            Btn_AbreChaves.Click += Btn_AbreChaves_Click;
            // 
            // Btn_AssentoS
            // 
            Btn_AssentoS.BackColor = SystemColors.ButtonShadow;
            Btn_AssentoS.Location = new Point(1153, 544);
            Btn_AssentoS.Margin = new Padding(3, 4, 3, 4);
            Btn_AssentoS.Name = "Btn_AssentoS";
            Btn_AssentoS.Size = new Size(86, 67);
            Btn_AssentoS.TabIndex = 110;
            Btn_AssentoS.Text = "`\r\n´\r\n";
            Btn_AssentoS.UseVisualStyleBackColor = false;
            Btn_AssentoS.Click += Btn_AssentoS_Click;
            // 
            // Btn_P
            // 
            Btn_P.BackColor = SystemColors.ButtonShadow;
            Btn_P.Location = new Point(875, 619);
            Btn_P.Margin = new Padding(3, 4, 3, 4);
            Btn_P.Name = "Btn_P";
            Btn_P.Size = new Size(86, 67);
            Btn_P.TabIndex = 109;
            Btn_P.Text = "P";
            Btn_P.UseVisualStyleBackColor = false;
            Btn_P.Click += Btn_P_Click;
            // 
            // Btn_O
            // 
            Btn_O.BackColor = SystemColors.ButtonShadow;
            Btn_O.Location = new Point(783, 619);
            Btn_O.Margin = new Padding(3, 4, 3, 4);
            Btn_O.Name = "Btn_O";
            Btn_O.Size = new Size(86, 67);
            Btn_O.TabIndex = 108;
            Btn_O.Text = "O";
            Btn_O.UseVisualStyleBackColor = false;
            Btn_O.Click += Btn_O_Click;
            // 
            // Btn_I
            // 
            Btn_I.BackColor = SystemColors.ButtonShadow;
            Btn_I.Location = new Point(690, 619);
            Btn_I.Margin = new Padding(3, 4, 3, 4);
            Btn_I.Name = "Btn_I";
            Btn_I.Size = new Size(86, 67);
            Btn_I.TabIndex = 107;
            Btn_I.Text = "I";
            Btn_I.UseVisualStyleBackColor = false;
            Btn_I.Click += Btn_I_Click;
            // 
            // Btn_U
            // 
            Btn_U.BackColor = SystemColors.ButtonShadow;
            Btn_U.Location = new Point(598, 619);
            Btn_U.Margin = new Padding(3, 4, 3, 4);
            Btn_U.Name = "Btn_U";
            Btn_U.Size = new Size(86, 67);
            Btn_U.TabIndex = 106;
            Btn_U.Text = "U";
            Btn_U.UseVisualStyleBackColor = false;
            Btn_U.Click += Btn_U_Click;
            // 
            // Btn_Y
            // 
            Btn_Y.BackColor = SystemColors.ButtonShadow;
            Btn_Y.Location = new Point(505, 619);
            Btn_Y.Margin = new Padding(3, 4, 3, 4);
            Btn_Y.Name = "Btn_Y";
            Btn_Y.Size = new Size(86, 67);
            Btn_Y.TabIndex = 105;
            Btn_Y.Text = "Y";
            Btn_Y.UseVisualStyleBackColor = false;
            Btn_Y.Click += Btn_Y_Click;
            // 
            // Btn_T
            // 
            Btn_T.BackColor = SystemColors.ButtonShadow;
            Btn_T.Location = new Point(413, 619);
            Btn_T.Margin = new Padding(3, 4, 3, 4);
            Btn_T.Name = "Btn_T";
            Btn_T.Size = new Size(86, 67);
            Btn_T.TabIndex = 104;
            Btn_T.Text = "T";
            Btn_T.UseVisualStyleBackColor = false;
            Btn_T.Click += Btn_T_Click;
            // 
            // Btn_R
            // 
            Btn_R.BackColor = SystemColors.ButtonShadow;
            Btn_R.Location = new Point(320, 619);
            Btn_R.Margin = new Padding(3, 4, 3, 4);
            Btn_R.Name = "Btn_R";
            Btn_R.Size = new Size(86, 67);
            Btn_R.TabIndex = 103;
            Btn_R.Text = "R";
            Btn_R.UseVisualStyleBackColor = false;
            Btn_R.Click += Btn_R_Click;
            // 
            // Btn_E
            // 
            Btn_E.BackColor = SystemColors.ButtonShadow;
            Btn_E.Location = new Point(227, 619);
            Btn_E.Margin = new Padding(3, 4, 3, 4);
            Btn_E.Name = "Btn_E";
            Btn_E.Size = new Size(86, 67);
            Btn_E.TabIndex = 102;
            Btn_E.Text = "E";
            Btn_E.UseVisualStyleBackColor = false;
            Btn_E.Click += Btn_E_Click;
            // 
            // Btn_W
            // 
            Btn_W.BackColor = SystemColors.ButtonShadow;
            Btn_W.Location = new Point(135, 619);
            Btn_W.Margin = new Padding(3, 4, 3, 4);
            Btn_W.Name = "Btn_W";
            Btn_W.Size = new Size(86, 67);
            Btn_W.TabIndex = 101;
            Btn_W.Text = "W";
            Btn_W.UseVisualStyleBackColor = false;
            Btn_W.Click += Btn_W_Click;
            // 
            // Btn_Q
            // 
            Btn_Q.BackColor = SystemColors.ButtonShadow;
            Btn_Q.Location = new Point(42, 619);
            Btn_Q.Margin = new Padding(3, 4, 3, 4);
            Btn_Q.Name = "Btn_Q";
            Btn_Q.Size = new Size(86, 67);
            Btn_Q.TabIndex = 100;
            Btn_Q.Text = "Q";
            Btn_Q.UseVisualStyleBackColor = false;
            Btn_Q.Click += Btn_Q_Click;
            // 
            // Btn_Dividir
            // 
            Btn_Dividir.BackColor = SystemColors.ButtonShadow;
            Btn_Dividir.Location = new Point(1337, 544);
            Btn_Dividir.Margin = new Padding(3, 4, 3, 4);
            Btn_Dividir.Name = "Btn_Dividir";
            Btn_Dividir.Size = new Size(86, 67);
            Btn_Dividir.TabIndex = 99;
            Btn_Dividir.Text = "/";
            Btn_Dividir.UseVisualStyleBackColor = false;
            Btn_Dividir.Click += Btn_Dividir_Click;
            // 
            // Btn_FechsChaves
            // 
            Btn_FechsChaves.BackColor = SystemColors.ButtonShadow;
            Btn_FechsChaves.Location = new Point(1061, 693);
            Btn_FechsChaves.Margin = new Padding(3, 4, 3, 4);
            Btn_FechsChaves.Name = "Btn_FechsChaves";
            Btn_FechsChaves.Size = new Size(86, 67);
            Btn_FechsChaves.TabIndex = 98;
            Btn_FechsChaves.Text = "}\r\n]";
            Btn_FechsChaves.UseVisualStyleBackColor = false;
            Btn_FechsChaves.Click += Btn_FechsChaves_Click;
            // 
            // Btn_MaisIgual
            // 
            Btn_MaisIgual.BackColor = SystemColors.ButtonShadow;
            Btn_MaisIgual.Location = new Point(1061, 768);
            Btn_MaisIgual.Margin = new Padding(3, 4, 3, 4);
            Btn_MaisIgual.Name = "Btn_MaisIgual";
            Btn_MaisIgual.Size = new Size(86, 67);
            Btn_MaisIgual.TabIndex = 97;
            Btn_MaisIgual.Text = "+\r\n=";
            Btn_MaisIgual.UseVisualStyleBackColor = false;
            Btn_MaisIgual.Click += Btn_MaisIgual_Click;
            // 
            // btn_UnderlaineeMenos
            // 
            btn_UnderlaineeMenos.BackColor = SystemColors.ButtonShadow;
            btn_UnderlaineeMenos.Location = new Point(1061, 544);
            btn_UnderlaineeMenos.Margin = new Padding(3, 4, 3, 4);
            btn_UnderlaineeMenos.Name = "btn_UnderlaineeMenos";
            btn_UnderlaineeMenos.Size = new Size(86, 67);
            btn_UnderlaineeMenos.TabIndex = 96;
            btn_UnderlaineeMenos.Text = "_\r\n-\r\n";
            btn_UnderlaineeMenos.UseVisualStyleBackColor = false;
            btn_UnderlaineeMenos.Click += btn_UnderlaineeMenos_Click;
            // 
            // btn_FechaParetenses
            // 
            btn_FechaParetenses.BackColor = SystemColors.ButtonShadow;
            btn_FechaParetenses.Location = new Point(785, 843);
            btn_FechaParetenses.Margin = new Padding(3, 4, 3, 4);
            btn_FechaParetenses.Name = "btn_FechaParetenses";
            btn_FechaParetenses.Size = new Size(86, 67);
            btn_FechaParetenses.TabIndex = 95;
            btn_FechaParetenses.Text = ")";
            btn_FechaParetenses.UseVisualStyleBackColor = false;
            btn_FechaParetenses.Click += btn_FechaParetenses_Click;
            // 
            // btn_AbriParetenses
            // 
            btn_AbriParetenses.BackColor = SystemColors.ButtonShadow;
            btn_AbriParetenses.Location = new Point(693, 843);
            btn_AbriParetenses.Margin = new Padding(3, 4, 3, 4);
            btn_AbriParetenses.Name = "btn_AbriParetenses";
            btn_AbriParetenses.Size = new Size(86, 67);
            btn_AbriParetenses.TabIndex = 94;
            btn_AbriParetenses.Text = "(";
            btn_AbriParetenses.UseVisualStyleBackColor = false;
            btn_AbriParetenses.Click += btn_AbriParetenses_Click;
            // 
            // btn_Asteristico
            // 
            btn_Asteristico.BackColor = SystemColors.ButtonShadow;
            btn_Asteristico.Location = new Point(783, 544);
            btn_Asteristico.Margin = new Padding(3, 4, 3, 4);
            btn_Asteristico.Name = "btn_Asteristico";
            btn_Asteristico.Size = new Size(86, 67);
            btn_Asteristico.TabIndex = 93;
            btn_Asteristico.Text = "*";
            btn_Asteristico.UseVisualStyleBackColor = false;
            btn_Asteristico.Click += btn_Asteristico_Click;
            // 
            // btn_Ecomercial
            // 
            btn_Ecomercial.BackColor = SystemColors.ButtonShadow;
            btn_Ecomercial.Location = new Point(690, 544);
            btn_Ecomercial.Margin = new Padding(3, 4, 3, 4);
            btn_Ecomercial.Name = "btn_Ecomercial";
            btn_Ecomercial.Size = new Size(86, 67);
            btn_Ecomercial.TabIndex = 92;
            btn_Ecomercial.Text = "&&";
            btn_Ecomercial.UseVisualStyleBackColor = false;
            btn_Ecomercial.Click += btn_Ecomercial_Click;
            // 
            // btn_doispontoscima
            // 
            btn_doispontoscima.BackColor = SystemColors.ButtonShadow;
            btn_doispontoscima.Location = new Point(598, 544);
            btn_doispontoscima.Margin = new Padding(3, 4, 3, 4);
            btn_doispontoscima.Name = "btn_doispontoscima";
            btn_doispontoscima.Size = new Size(86, 67);
            btn_doispontoscima.TabIndex = 91;
            btn_doispontoscima.Text = "¨";
            btn_doispontoscima.UseVisualStyleBackColor = false;
            btn_doispontoscima.Click += btn_doispontoscima_Click;
            // 
            // btn_Porcetagem
            // 
            btn_Porcetagem.BackColor = SystemColors.ButtonShadow;
            btn_Porcetagem.Location = new Point(505, 544);
            btn_Porcetagem.Margin = new Padding(3, 4, 3, 4);
            btn_Porcetagem.Name = "btn_Porcetagem";
            btn_Porcetagem.Size = new Size(86, 67);
            btn_Porcetagem.TabIndex = 90;
            btn_Porcetagem.Text = "%";
            btn_Porcetagem.UseVisualStyleBackColor = false;
            btn_Porcetagem.Click += btn_Porcetagem_Click;
            // 
            // btn_sifrao
            // 
            btn_sifrao.BackColor = SystemColors.ButtonShadow;
            btn_sifrao.Location = new Point(413, 544);
            btn_sifrao.Margin = new Padding(3, 4, 3, 4);
            btn_sifrao.Name = "btn_sifrao";
            btn_sifrao.Size = new Size(86, 67);
            btn_sifrao.TabIndex = 89;
            btn_sifrao.Text = "$";
            btn_sifrao.UseVisualStyleBackColor = false;
            btn_sifrao.Click += btn_sifrao_Click;
            // 
            // btn_hastag
            // 
            btn_hastag.BackColor = SystemColors.ButtonShadow;
            btn_hastag.Location = new Point(320, 544);
            btn_hastag.Margin = new Padding(3, 4, 3, 4);
            btn_hastag.Name = "btn_hastag";
            btn_hastag.Size = new Size(86, 67);
            btn_hastag.TabIndex = 88;
            btn_hastag.Text = "#";
            btn_hastag.UseVisualStyleBackColor = false;
            btn_hastag.Click += btn_hastag_Click;
            // 
            // btn_Arroba
            // 
            btn_Arroba.BackColor = SystemColors.ButtonShadow;
            btn_Arroba.Location = new Point(227, 544);
            btn_Arroba.Margin = new Padding(3, 4, 3, 4);
            btn_Arroba.Name = "btn_Arroba";
            btn_Arroba.Size = new Size(86, 67);
            btn_Arroba.TabIndex = 87;
            btn_Arroba.Text = "@";
            btn_Arroba.UseVisualStyleBackColor = false;
            btn_Arroba.Click += btn_Arroba_Click;
            // 
            // btn_esclamacao
            // 
            btn_esclamacao.BackColor = SystemColors.ButtonShadow;
            btn_esclamacao.Location = new Point(135, 544);
            btn_esclamacao.Margin = new Padding(3, 4, 3, 4);
            btn_esclamacao.Name = "btn_esclamacao";
            btn_esclamacao.Size = new Size(86, 67);
            btn_esclamacao.TabIndex = 86;
            btn_esclamacao.Text = "!";
            btn_esclamacao.UseVisualStyleBackColor = false;
            btn_esclamacao.Click += btn_esclamacao_Click;
            // 
            // btn_Aspas
            // 
            btn_Aspas.BackColor = SystemColors.ButtonShadow;
            btn_Aspas.Location = new Point(42, 544);
            btn_Aspas.Margin = new Padding(3, 4, 3, 4);
            btn_Aspas.Name = "btn_Aspas";
            btn_Aspas.Size = new Size(86, 67);
            btn_Aspas.TabIndex = 85;
            btn_Aspas.Text = "\"\r\n'";
            btn_Aspas.UseVisualStyleBackColor = false;
            btn_Aspas.Click += btn_Aspas_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            label3.ForeColor = SystemColors.ButtonFace;
            label3.Location = new Point(135, 211);
            label3.Name = "label3";
            label3.Size = new Size(88, 31);
            label3.TabIndex = 161;
            label3.Text = "Senha:";
            // 
            // txt_Senha_login
            // 
            txt_Senha_login.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            txt_Senha_login.ForeColor = SystemColors.ButtonFace;
            txt_Senha_login.Location = new Point(135, 247);
            txt_Senha_login.Margin = new Padding(3, 4, 3, 4);
            txt_Senha_login.Name = "txt_Senha_login";
            txt_Senha_login.Size = new Size(321, 38);
            txt_Senha_login.TabIndex = 160;
            txt_Senha_login.Click += TxbSenhaLogin;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 36F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(67, 9);
            label1.Name = "label1";
            label1.Size = new Size(446, 69);
            label1.TabIndex = 159;
            label1.Text = "Realize seu Login";
            label1.TextAlign = ContentAlignment.MiddleLeft;
            // 
            // lbl_Nome
            // 
            lbl_Nome.AutoSize = true;
            lbl_Nome.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            lbl_Nome.ForeColor = SystemColors.ButtonFace;
            lbl_Nome.Location = new Point(131, 105);
            lbl_Nome.Name = "lbl_Nome";
            lbl_Nome.Size = new Size(89, 31);
            lbl_Nome.TabIndex = 157;
            lbl_Nome.Text = "Nome: ";
            // 
            // txb_Nome_login
            // 
            txb_Nome_login.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold);
            txb_Nome_login.ForeColor = SystemColors.ButtonFace;
            txb_Nome_login.Location = new Point(135, 141);
            txb_Nome_login.Margin = new Padding(3, 4, 3, 4);
            txb_Nome_login.Name = "txb_Nome_login";
            txb_Nome_login.Size = new Size(321, 38);
            txb_Nome_login.TabIndex = 155;
            txb_Nome_login.Click += TxbNomeLogin;
            // 
            // Btn_Cadastro
            // 
            Btn_Cadastro.Location = new Point(1655, 477);
            Btn_Cadastro.Margin = new Padding(3, 4, 3, 4);
            Btn_Cadastro.Name = "Btn_Cadastro";
            Btn_Cadastro.Size = new Size(96, 111);
            Btn_Cadastro.TabIndex = 162;
            Btn_Cadastro.Text = "Realize aqui,\r\nSeu Cadastro";
            Btn_Cadastro.UseVisualStyleBackColor = true;
            Btn_Cadastro.Click += Btn_Cadastro_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Lua_Primeiro_quarto_First_quarter_moon;
            pictureBox1.Location = new Point(946, 0);
            pictureBox1.Margin = new Padding(3, 4, 3, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(521, 452);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 163;
            pictureBox1.TabStop = false;
            // 
            // Btn_Entrar
            // 
            Btn_Entrar.BackColor = SystemColors.ButtonShadow;
            Btn_Entrar.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Entrar.Location = new Point(135, 339);
            Btn_Entrar.Margin = new Padding(3, 4, 3, 4);
            Btn_Entrar.Name = "Btn_Entrar";
            Btn_Entrar.Size = new Size(226, 40);
            Btn_Entrar.TabIndex = 164;
            Btn_Entrar.Text = "Entrar";
            Btn_Entrar.UseVisualStyleBackColor = false;
            Btn_Entrar.Click += Btn_Entrar_Click;
            // 
            // Btn_IrCadastro
            // 
            Btn_IrCadastro.BackColor = SystemColors.ButtonShadow;
            Btn_IrCadastro.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_IrCadastro.Location = new Point(135, 387);
            Btn_IrCadastro.Margin = new Padding(3, 4, 3, 4);
            Btn_IrCadastro.Name = "Btn_IrCadastro";
            Btn_IrCadastro.Size = new Size(109, 37);
            Btn_IrCadastro.TabIndex = 165;
            Btn_IrCadastro.Text = "Cadastre-se ";
            Btn_IrCadastro.UseVisualStyleBackColor = false;
            Btn_IrCadastro.Click += Btn_IrCadastro_Click;
            // 
            // Btn_IrHome
            // 
            Btn_IrHome.BackColor = SystemColors.ButtonShadow;
            Btn_IrHome.Font = new Font("Arial Narrow", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_IrHome.Location = new Point(250, 387);
            Btn_IrHome.Margin = new Padding(3, 4, 3, 4);
            Btn_IrHome.Name = "Btn_IrHome";
            Btn_IrHome.Size = new Size(111, 37);
            Btn_IrHome.TabIndex = 166;
            Btn_IrHome.Text = "Home";
            Btn_IrHome.UseVisualStyleBackColor = false;
            Btn_IrHome.Click += Btn_IrHome_Click;
            // 
            // Login
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1467, 948);
            Controls.Add(Btn_IrHome);
            Controls.Add(Btn_IrCadastro);
            Controls.Add(Btn_Entrar);
            Controls.Add(pictureBox1);
            Controls.Add(Btn_Cadastro);
            Controls.Add(label3);
            Controls.Add(txt_Senha_login);
            Controls.Add(label1);
            Controls.Add(lbl_Nome);
            Controls.Add(txb_Nome_login);
            Controls.Add(chn_CapsLock);
            Controls.Add(Chn_Shift);
            Controls.Add(Btn_Sair);
            Controls.Add(Btn_Tres);
            Controls.Add(Btn_PontoDir);
            Controls.Add(Btn_Seis);
            Controls.Add(Btn_Soma);
            Controls.Add(Btn_Nove);
            Controls.Add(Btn_Menos);
            Controls.Add(Btn_Multiplicar);
            Controls.Add(Btn_Dois);
            Controls.Add(Btn_Um);
            Controls.Add(Btn_Zero);
            Controls.Add(Btn_VirgulaDir);
            Controls.Add(button53);
            Controls.Add(Btn_PontoVirgila);
            Controls.Add(Btn_Ponto);
            Controls.Add(Btn_Virgula);
            Controls.Add(Btn_M);
            Controls.Add(Btn_N);
            Controls.Add(Btn_B);
            Controls.Add(Btn_V);
            Controls.Add(Btn_C);
            Controls.Add(Btn_X);
            Controls.Add(Btn_Z);
            Controls.Add(Btn_Cinco);
            Controls.Add(Btn_Quatro);
            Controls.Add(Btn_Salvar);
            Controls.Add(Btn_Interogacao);
            Controls.Add(Btn_ChapeueCobra);
            Controls.Add(Btn_Ç);
            Controls.Add(Btn_L);
            Controls.Add(Btn_K);
            Controls.Add(Btn_J);
            Controls.Add(Btn_H);
            Controls.Add(Btn_G);
            Controls.Add(Btn_F);
            Controls.Add(Btn_D);
            Controls.Add(Btn_S);
            Controls.Add(Btn_A);
            Controls.Add(Btn_Oito);
            Controls.Add(Btn_Sete);
            Controls.Add(Btn_Backspage);
            Controls.Add(Btn_AbreChaves);
            Controls.Add(Btn_AssentoS);
            Controls.Add(Btn_P);
            Controls.Add(Btn_O);
            Controls.Add(Btn_I);
            Controls.Add(Btn_U);
            Controls.Add(Btn_Y);
            Controls.Add(Btn_T);
            Controls.Add(Btn_R);
            Controls.Add(Btn_E);
            Controls.Add(Btn_W);
            Controls.Add(Btn_Q);
            Controls.Add(Btn_Dividir);
            Controls.Add(Btn_FechsChaves);
            Controls.Add(Btn_MaisIgual);
            Controls.Add(btn_UnderlaineeMenos);
            Controls.Add(btn_FechaParetenses);
            Controls.Add(btn_AbriParetenses);
            Controls.Add(btn_Asteristico);
            Controls.Add(btn_Ecomercial);
            Controls.Add(btn_doispontoscima);
            Controls.Add(btn_Porcetagem);
            Controls.Add(btn_sifrao);
            Controls.Add(btn_hastag);
            Controls.Add(btn_Arroba);
            Controls.Add(btn_esclamacao);
            Controls.Add(btn_Aspas);
            Margin = new Padding(3, 4, 3, 4);
            Name = "Login";
            Text = "Login";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private CheckBox chn_CapsLock;
        private CheckBox Chn_Shift;
        private Button Btn_Sair;
        private Button Btn_Tres;
        private Button Btn_PontoDir;
        private Button Btn_Seis;
        private Button Btn_Soma;
        private Button Btn_Nove;
        private Button Btn_Menos;
        private Button Btn_Multiplicar;
        private Button Btn_Dois;
        private Button Btn_Um;
        private Button Btn_Zero;
        private Button Btn_VirgulaDir;
        private Button button53;
        private Button Btn_PontoVirgila;
        private Button Btn_Ponto;
        private Button Btn_Virgula;
        private Button Btn_M;
        private Button Btn_N;
        private Button Btn_B;
        private Button Btn_V;
        private Button Btn_C;
        private Button Btn_X;
        private Button Btn_Z;
        private Button Btn_Cinco;
        private Button Btn_Quatro;
        private Button Btn_Salvar;
        private Button Btn_Interogacao;
        private Button Btn_ChapeueCobra;
        private Button Btn_Ç;
        private Button Btn_L;
        private Button Btn_K;
        private Button Btn_J;
        private Button Btn_H;
        private Button Btn_G;
        private Button Btn_F;
        private Button Btn_D;
        private Button Btn_S;
        private Button Btn_A;
        private Button Btn_Oito;
        private Button Btn_Sete;
        private Button Btn_Backspage;
        private Button Btn_AbreChaves;
        private Button Btn_AssentoS;
        private Button Btn_P;
        private Button Btn_O;
        private Button Btn_I;
        private Button Btn_U;
        private Button Btn_Y;
        private Button Btn_T;
        private Button Btn_R;
        private Button Btn_E;
        private Button Btn_W;
        private Button Btn_Q;
        private Button Btn_Dividir;
        private Button Btn_FechsChaves;
        private Button Btn_MaisIgual;
        private Button btn_UnderlaineeMenos;
        private Button btn_FechaParetenses;
        private Button btn_AbriParetenses;
        private Button btn_Asteristico;
        private Button btn_Ecomercial;
        private Button btn_doispontoscima;
        private Button btn_Porcetagem;
        private Button btn_sifrao;
        private Button btn_hastag;
        private Button btn_Arroba;
        private Button btn_esclamacao;
        private Button btn_Aspas;
        private Label label3;
        private TextBox txt_Senha_login;
        private Label label1;
        private Label lbl_Nome;
        private TextBox txb_Nome_login;
        private Button Btn_Cadastro;
        private PictureBox pictureBox1;
        private Button Btn_Entrar;
        private Button Btn_IrCadastro;
        private Button Btn_IrHome;
    }
}