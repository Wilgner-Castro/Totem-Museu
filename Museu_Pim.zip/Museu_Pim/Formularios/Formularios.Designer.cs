﻿namespace Museu_Pim.Formularios
{
    partial class Formularios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            Btn_Qustionarios = new Button();
            Btn_Relatorio = new Button();
            Btn_Voltar_Home = new Button();
            Conhe = new Label();
            pictureBox1 = new PictureBox();
            pictureBox2 = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            SuspendLayout();
            // 
            // Btn_Qustionarios
            // 
            Btn_Qustionarios.BackColor = SystemColors.ActiveBorder;
            Btn_Qustionarios.ForeColor = SystemColors.ActiveCaptionText;
            Btn_Qustionarios.Location = new Point(539, 357);
            Btn_Qustionarios.Name = "Btn_Qustionarios";
            Btn_Qustionarios.Size = new Size(164, 52);
            Btn_Qustionarios.TabIndex = 0;
            Btn_Qustionarios.Text = "Inicie o questionario";
            Btn_Qustionarios.UseVisualStyleBackColor = false;
            Btn_Qustionarios.Click += Btn_Qustionarios_Click;
            // 
            // Btn_Relatorio
            // 
            Btn_Relatorio.BackColor = SystemColors.ActiveBorder;
            Btn_Relatorio.ForeColor = SystemColors.ActiveCaptionText;
            Btn_Relatorio.Location = new Point(539, 439);
            Btn_Relatorio.Name = "Btn_Relatorio";
            Btn_Relatorio.Size = new Size(164, 52);
            Btn_Relatorio.TabIndex = 1;
            Btn_Relatorio.Text = "Relatorio";
            Btn_Relatorio.UseVisualStyleBackColor = false;
            Btn_Relatorio.Click += Btn_Relatorio_Click;
            // 
            // Btn_Voltar_Home
            // 
            Btn_Voltar_Home.BackColor = SystemColors.ActiveBorder;
            Btn_Voltar_Home.ForeColor = SystemColors.ActiveCaptionText;
            Btn_Voltar_Home.Location = new Point(539, 522);
            Btn_Voltar_Home.Name = "Btn_Voltar_Home";
            Btn_Voltar_Home.Size = new Size(164, 52);
            Btn_Voltar_Home.TabIndex = 2;
            Btn_Voltar_Home.Text = "Home";
            Btn_Voltar_Home.UseVisualStyleBackColor = false;
            Btn_Voltar_Home.Click += Btn_Voltar_Home_Click;
            // 
            // Conhe
            // 
            Conhe.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            Conhe.AutoSize = true;
            Conhe.Font = new Font("Arial", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Conhe.Location = new Point(301, 182);
            Conhe.Name = "Conhe";
            Conhe.Size = new Size(623, 72);
            Conhe.TabIndex = 3;
            Conhe.Text = "Agora que você ja visualizou nossas obras venha descobrir \r\nseu conhecimento seu aprendizado e deixar seu feedback \r\n    sobre nosso museu\r\n";
            Conhe.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Lua_Primeiro_quarto_First_quarter_moon;
            pictureBox1.Location = new Point(866, -40);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(429, 531);
            pictureBox1.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox1.TabIndex = 4;
            pictureBox1.TabStop = false;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.AMOLED_Space_Wallpaper_21___Fondos_de_pantalla_de_iphone__Fotos_de_la_tierra__Imagenes_abstractas;
            pictureBox2.Location = new Point(0, 328);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(433, 401);
            pictureBox2.SizeMode = PictureBoxSizeMode.CenterImage;
            pictureBox2.TabIndex = 5;
            pictureBox2.TabStop = false;
            // 
            // Formularios
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1284, 711);
            Controls.Add(pictureBox2);
            Controls.Add(Conhe);
            Controls.Add(Btn_Voltar_Home);
            Controls.Add(Btn_Relatorio);
            Controls.Add(Btn_Qustionarios);
            Controls.Add(pictureBox1);
            ForeColor = SystemColors.ButtonFace;
            Name = "Formularios";
            Text = "Formularios";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button Btn_Qustionarios;
        private Button Btn_Relatorio;
        private Button Btn_Voltar_Home;
        private Label Conhe;
        private PictureBox pictureBox1;
        private PictureBox pictureBox2;
    }
}