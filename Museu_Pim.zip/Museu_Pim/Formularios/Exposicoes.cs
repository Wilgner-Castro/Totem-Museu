﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Museu_Pim.Formularios
{
    public partial class Exposicoes : Form
    {
        public Exposicoes()
        {
            InitializeComponent();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            Form Janela_Formulario = new Formularios();
            Janela_Formulario.Show();
         
        }

        private void button4_Click(object sender, EventArgs e)
        {
            Form Janela_Home = new Home();
            Janela_Home.Show();
      
        }

        private void btn_ProximaObra_Click(object sender, EventArgs e)
        {
            Form Janela_MissaoApolo = new MissaoApolo();
            Janela_MissaoApolo.Show();
           
        }
    }
}
