﻿namespace Museu_Pim.Formularios
{
    partial class Exposicoes
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Exposicoes));
            button1 = new Button();
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btn_ProximaObra = new Button();
            Btn_Formulario = new Button();
            Btn_voltarHome = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // button1
            // 
            button1.BackColor = Color.FromArgb(255, 255, 128);
            button1.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            button1.Location = new Point(103, 25);
            button1.Name = "button1";
            button1.Size = new Size(427, 56);
            button1.TabIndex = 0;
            button1.Text = "Historia";
            button1.UseVisualStyleBackColor = false;
            // 
            // pictureBox1
            // 
            pictureBox1.BackgroundImage = Properties.Resources.Neil_Armstrong_postcard;
            pictureBox1.BackgroundImageLayout = ImageLayout.Zoom;
            pictureBox1.Location = new Point(824, 39);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(428, 631);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            pictureBox1.Click += pictureBox1_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(12, 117);
            label1.Name = "label1";
            label1.Size = new Size(818, 460);
            label1.TabIndex = 2;
            label1.Text = resources.GetString("label1.Text");
            // 
            // btn_ProximaObra
            // 
            btn_ProximaObra.BackColor = Color.FromArgb(255, 255, 128);
            btn_ProximaObra.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            btn_ProximaObra.Location = new Point(472, 645);
            btn_ProximaObra.Name = "btn_ProximaObra";
            btn_ProximaObra.Size = new Size(264, 54);
            btn_ProximaObra.TabIndex = 3;
            btn_ProximaObra.Text = "Proxima Obra";
            btn_ProximaObra.UseVisualStyleBackColor = false;
            btn_ProximaObra.Click += btn_ProximaObra_Click;
            // 
            // Btn_Formulario
            // 
            Btn_Formulario.BackColor = Color.FromArgb(255, 255, 128);
            Btn_Formulario.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            Btn_Formulario.Location = new Point(242, 645);
            Btn_Formulario.Name = "Btn_Formulario";
            Btn_Formulario.Size = new Size(224, 54);
            Btn_Formulario.TabIndex = 4;
            Btn_Formulario.Text = "Formulario";
            Btn_Formulario.UseVisualStyleBackColor = false;
            Btn_Formulario.Click += button3_Click;
            // 
            // Btn_voltarHome
            // 
            Btn_voltarHome.BackColor = Color.FromArgb(255, 255, 128);
            Btn_voltarHome.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            Btn_voltarHome.Location = new Point(12, 645);
            Btn_voltarHome.Name = "Btn_voltarHome";
            Btn_voltarHome.Size = new Size(224, 54);
            Btn_voltarHome.TabIndex = 5;
            Btn_voltarHome.Text = "Home";
            Btn_voltarHome.UseVisualStyleBackColor = false;
            Btn_voltarHome.Click += button4_Click;
            // 
            // Exposicoes
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1284, 711);
            Controls.Add(Btn_voltarHome);
            Controls.Add(Btn_Formulario);
            Controls.Add(btn_ProximaObra);
            Controls.Add(button1);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Name = "Exposicoes";
            Text = "Exposicoes";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button1;
        private PictureBox pictureBox1;
        private Label label1;
        private Button btn_ProximaObra;
        private Button Btn_Formulario;
        private Button Btn_voltarHome;
    }
}