﻿namespace Museu_Pim.Formularios
{
    partial class Home
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            perfilToolStripMenuItem = new ToolStripMenuItem();
            cadastroToolStripMenuItem = new ToolStripMenuItem();
            loginToolStripMenuItem = new ToolStripMenuItem();
            obrasToolStripMenuItem = new ToolStripMenuItem();
            exposiçõesToolStripMenuItem = new ToolStripMenuItem();
            formuláriosToolStripMenuItem = new ToolStripMenuItem();
            mapaMuseuToolStripMenuItem = new ToolStripMenuItem();
            sairToolStripMenuItem = new ToolStripMenuItem();
            pictureBox1 = new PictureBox();
            Btn_Historia = new Button();
            Btn_MissaoApollo = new Button();
            Btn_Biografia = new Button();
            label1 = new Label();
            pictureBox2 = new PictureBox();
            pictureBox3 = new PictureBox();
            menuStrip1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { perfilToolStripMenuItem, obrasToolStripMenuItem, mapaMuseuToolStripMenuItem, sairToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(1284, 24);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // perfilToolStripMenuItem
            // 
            perfilToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { cadastroToolStripMenuItem, loginToolStripMenuItem });
            perfilToolStripMenuItem.Name = "perfilToolStripMenuItem";
            perfilToolStripMenuItem.Size = new Size(46, 20);
            perfilToolStripMenuItem.Text = "Perfil";
            // 
            // cadastroToolStripMenuItem
            // 
            cadastroToolStripMenuItem.Name = "cadastroToolStripMenuItem";
            cadastroToolStripMenuItem.Size = new Size(121, 22);
            cadastroToolStripMenuItem.Text = "Cadastro";
            cadastroToolStripMenuItem.Click += cadastroToolStripMenuItem_Click;
            // 
            // loginToolStripMenuItem
            // 
            loginToolStripMenuItem.Name = "loginToolStripMenuItem";
            loginToolStripMenuItem.Size = new Size(121, 22);
            loginToolStripMenuItem.Text = "Login";
            loginToolStripMenuItem.Click += loginToolStripMenuItem_Click;
            // 
            // obrasToolStripMenuItem
            // 
            obrasToolStripMenuItem.DropDownItems.AddRange(new ToolStripItem[] { exposiçõesToolStripMenuItem, formuláriosToolStripMenuItem });
            obrasToolStripMenuItem.Name = "obrasToolStripMenuItem";
            obrasToolStripMenuItem.Size = new Size(50, 20);
            obrasToolStripMenuItem.Text = "Obras";
            // 
            // exposiçõesToolStripMenuItem
            // 
            exposiçõesToolStripMenuItem.Name = "exposiçõesToolStripMenuItem";
            exposiçõesToolStripMenuItem.Size = new Size(137, 22);
            exposiçõesToolStripMenuItem.Text = "Exposições";
            exposiçõesToolStripMenuItem.Click += exposiçõesToolStripMenuItem_Click;
            // 
            // formuláriosToolStripMenuItem
            // 
            formuláriosToolStripMenuItem.Name = "formuláriosToolStripMenuItem";
            formuláriosToolStripMenuItem.Size = new Size(137, 22);
            formuláriosToolStripMenuItem.Text = "Formulários";
            formuláriosToolStripMenuItem.Click += formuláriosToolStripMenuItem_Click;
            // 
            // mapaMuseuToolStripMenuItem
            // 
            mapaMuseuToolStripMenuItem.Name = "mapaMuseuToolStripMenuItem";
            mapaMuseuToolStripMenuItem.Size = new Size(88, 20);
            mapaMuseuToolStripMenuItem.Text = "Mapa Museu";
            mapaMuseuToolStripMenuItem.Click += mapaMuseuToolStripMenuItem_Click;
            // 
            // sairToolStripMenuItem
            // 
            sairToolStripMenuItem.Name = "sairToolStripMenuItem";
            sairToolStripMenuItem.Size = new Size(38, 20);
            sairToolStripMenuItem.Text = "Sair";
            sairToolStripMenuItem.Click += sairToolStripMenuItem_Click;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.viagem_do_homem_a_lua;
            pictureBox1.Location = new Point(65, 41);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(409, 648);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Btn_Historia
            // 
            Btn_Historia.BackColor = SystemColors.ButtonShadow;
            Btn_Historia.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Historia.Location = new Point(813, 284);
            Btn_Historia.Name = "Btn_Historia";
            Btn_Historia.Size = new Size(150, 45);
            Btn_Historia.TabIndex = 2;
            Btn_Historia.Text = "Historia";
            Btn_Historia.UseVisualStyleBackColor = false;
            Btn_Historia.Click += Btn_Historia_Click;
            // 
            // Btn_MissaoApollo
            // 
            Btn_MissaoApollo.BackColor = SystemColors.ButtonShadow;
            Btn_MissaoApollo.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_MissaoApollo.ForeColor = SystemColors.ActiveCaptionText;
            Btn_MissaoApollo.Location = new Point(813, 370);
            Btn_MissaoApollo.Name = "Btn_MissaoApollo";
            Btn_MissaoApollo.Size = new Size(153, 45);
            Btn_MissaoApollo.TabIndex = 3;
            Btn_MissaoApollo.Text = "Missão Apollo";
            Btn_MissaoApollo.UseVisualStyleBackColor = false;
            Btn_MissaoApollo.Click += Btn_MissaoApollo_Click;
            // 
            // Btn_Biografia
            // 
            Btn_Biografia.BackColor = SystemColors.ButtonShadow;
            Btn_Biografia.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Btn_Biografia.Location = new Point(813, 457);
            Btn_Biografia.Name = "Btn_Biografia";
            Btn_Biografia.Size = new Size(150, 45);
            Btn_Biografia.TabIndex = 4;
            Btn_Biografia.Text = "Biografia";
            Btn_Biografia.UseVisualStyleBackColor = false;
            Btn_Biografia.Click += Btn_Biografia_Click;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial", 24F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(518, 148);
            label1.Name = "label1";
            label1.Size = new Size(754, 74);
            label1.TabIndex = 5;
            label1.Text = "\"esse é um pequeno passso para o homem mas \r\num grande passo pra humanidade\"\r\n";
            label1.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // pictureBox2
            // 
            pictureBox2.Image = Properties.Resources.Apollo11;
            pictureBox2.Location = new Point(542, 457);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(178, 226);
            pictureBox2.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox2.TabIndex = 6;
            pictureBox2.TabStop = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = Properties.Resources.Linda_lua_cheia_cinza_brilhante___Foto_Grátis;
            pictureBox3.Location = new Point(1069, 272);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(178, 144);
            pictureBox3.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox3.TabIndex = 7;
            pictureBox3.TabStop = false;
            // 
            // Home
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.Black;
            ClientSize = new Size(1284, 711);
            Controls.Add(pictureBox3);
            Controls.Add(pictureBox2);
            Controls.Add(label1);
            Controls.Add(Btn_Biografia);
            Controls.Add(Btn_MissaoApollo);
            Controls.Add(Btn_Historia);
            Controls.Add(pictureBox1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Home";
            Text = "Home";
            Load += Home_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem perfilToolStripMenuItem;
        private ToolStripMenuItem cadastroToolStripMenuItem;
        private ToolStripMenuItem loginToolStripMenuItem;
        private ToolStripMenuItem obrasToolStripMenuItem;
        private ToolStripMenuItem exposiçõesToolStripMenuItem;
        private ToolStripMenuItem formuláriosToolStripMenuItem;
        private ToolStripMenuItem mapaMuseuToolStripMenuItem;
        private ToolStripMenuItem sairToolStripMenuItem;
        private PictureBox pictureBox1;
        private Button Btn_Historia;
        private Button Btn_MissaoApollo;
        private Button Btn_Biografia;
        private Label label1;
        private PictureBox pictureBox2;
        private PictureBox pictureBox3;
    }
}