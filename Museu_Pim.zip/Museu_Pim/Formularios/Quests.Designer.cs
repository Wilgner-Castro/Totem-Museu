﻿namespace Museu_Pim.Modulos
{
    partial class Quests
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Quests));
            pictureBox1 = new PictureBox();
            LblAtraçao = new Label();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(159, 11);
            pictureBox1.Margin = new Padding(3, 2, 3, 2);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(535, 312);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // LblAtraçao
            // 
            LblAtraçao.Font = new Font("Arial Narrow", 15.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            LblAtraçao.ForeColor = SystemColors.ButtonFace;
            LblAtraçao.Location = new Point(12, 335);
            LblAtraçao.Name = "LblAtraçao";
            LblAtraçao.Size = new Size(802, 34);
            LblAtraçao.TabIndex = 1;
            LblAtraçao.Text = "Atrações";
            LblAtraçao.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // button1
            // 
            button1.BackColor = SystemColors.ButtonShadow;
            button1.Font = new Font("Arial", 12F);
            button1.Location = new Point(49, 371);
            button1.Margin = new Padding(3, 2, 3, 2);
            button1.Name = "button1";
            button1.Size = new Size(298, 56);
            button1.TabIndex = 2;
            button1.Tag = "1";
            button1.Text = "button1";
            button1.UseVisualStyleBackColor = false;
            button1.Click += Verificarevento;
            // 
            // button2
            // 
            button2.BackColor = SystemColors.ButtonShadow;
            button2.Font = new Font("Arial", 12F);
            button2.Location = new Point(479, 371);
            button2.Margin = new Padding(3, 2, 3, 2);
            button2.Name = "button2";
            button2.Size = new Size(298, 56);
            button2.TabIndex = 6;
            button2.Tag = "2";
            button2.Text = "button2";
            button2.UseVisualStyleBackColor = false;
            button2.Click += Verificarevento;
            // 
            // button3
            // 
            button3.BackColor = SystemColors.ButtonShadow;
            button3.Font = new Font("Arial", 12F);
            button3.Location = new Point(49, 442);
            button3.Margin = new Padding(3, 2, 3, 2);
            button3.Name = "button3";
            button3.Size = new Size(298, 56);
            button3.TabIndex = 7;
            button3.Tag = "3";
            button3.Text = "button3";
            button3.UseVisualStyleBackColor = false;
            button3.Click += Verificarevento;
            // 
            // button4
            // 
            button4.BackColor = SystemColors.ButtonShadow;
            button4.Font = new Font("Arial", 12F);
            button4.Location = new Point(479, 442);
            button4.Margin = new Padding(3, 2, 3, 2);
            button4.Name = "button4";
            button4.Size = new Size(298, 56);
            button4.TabIndex = 8;
            button4.Tag = "4";
            button4.Text = "button4";
            button4.UseVisualStyleBackColor = false;
            button4.Click += Verificarevento;
            // 
            // Quests
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(831, 511);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(LblAtraçao);
            Controls.Add(pictureBox1);
            Margin = new Padding(3, 2, 3, 2);
            Name = "Quests";
            Text = "Questionario";
            Load += Forms_Load;
            Click += Verificarevento;
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private PictureBox pictureBox1;
        private Label LblAtraçao;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button4;
    }
}