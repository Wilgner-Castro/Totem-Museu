﻿using Museu_Pim.Modulos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Museu_Pim.Formularios
{
    public partial class Formularios : Form
    {
        public Formularios()
        {
            InitializeComponent();
        }

        private void Btn_Voltar_Home_Click(object sender, EventArgs e)
        {
            Form Janela_Home = new Home();
            Janela_Home.Show();
        }

        private void Btn_Relatorio_Click(object sender, EventArgs e)
        {
            Form Janela_Relatorio = new Relatorio();
            Janela_Relatorio.Show();
        }

        private void Btn_Qustionarios_Click(object sender, EventArgs e)
        {
            Form Janela_Quests = new Quests();
            Janela_Quests.Show();
        }
    }
}
