﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Museu_Pim.Formularios
{
    public partial class Mapa_Museu : Form
    {
        public Mapa_Museu()
        {
            InitializeComponent();
        }

        private void cadastroToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Janela_Cadastro = new Cadastro();
            Janela_Cadastro.Show();
          
        }

        private void loginToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Janela_Login = new Login();
            Janela_Login.Show();
         
        }

        private void exposiçõesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Janela_Home = new Home();
            Janela_Home.Show();
           
        }

        private void formulariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form Janela_Formularios = new Formularios();
            Janela_Formularios.Show();
          
        }

        private void sairToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
