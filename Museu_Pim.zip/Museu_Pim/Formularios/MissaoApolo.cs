﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Museu_Pim.Formularios
{
    public partial class MissaoApolo : Form
    {
        public MissaoApolo()
        {
            InitializeComponent();
        }

        private void Btn_Home_Click(object sender, EventArgs e)
        {
            Form Janela_Home = new Home();
            Janela_Home.Show();
           
        }

        private void Btn_ProximaObra_Click(object sender, EventArgs e)
        {
            Form Janela_Bibliografia = new Bibliografia();
            Janela_Bibliografia.Show();
           
        }

        private void btn_formulario_Click(object sender, EventArgs e)
        {
            Form Janela_Formulario = new Formularios();
            Janela_Formulario.Show();
            
        }
    }
}
