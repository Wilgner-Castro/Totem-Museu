﻿namespace Museu_Pim.Formularios
{
    partial class MissaoApolo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MissaoApolo));
            label1 = new Label();
            pictureBox1 = new PictureBox();
            Btn_voltarHome = new Button();
            Btn_Home = new Button();
            btn_formulario = new Button();
            Btn_ProximaObra = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Arial Narrow", 14.25F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.ForeColor = SystemColors.ButtonFace;
            label1.Location = new Point(463, 9);
            label1.Name = "label1";
            label1.Size = new Size(809, 621);
            label1.TabIndex = 0;
            label1.Text = resources.GetString("label1.Text");
            // 
            // pictureBox1
            // 
            pictureBox1.Image = Properties.Resources.Apollo_11_Photos_and_Premium_High_Res_Pictures;
            pictureBox1.Location = new Point(29, 96);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(408, 579);
            pictureBox1.TabIndex = 1;
            pictureBox1.TabStop = false;
            // 
            // Btn_voltarHome
            // 
            Btn_voltarHome.BackColor = Color.FromArgb(255, 255, 128);
            Btn_voltarHome.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            Btn_voltarHome.Location = new Point(64, 22);
            Btn_voltarHome.Name = "Btn_voltarHome";
            Btn_voltarHome.Size = new Size(356, 54);
            Btn_voltarHome.TabIndex = 6;
            Btn_voltarHome.Text = "Missão Apollo";
            Btn_voltarHome.UseVisualStyleBackColor = false;
            // 
            // Btn_Home
            // 
            Btn_Home.BackColor = Color.FromArgb(255, 255, 128);
            Btn_Home.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            Btn_Home.Location = new Point(467, 645);
            Btn_Home.Name = "Btn_Home";
            Btn_Home.Size = new Size(260, 54);
            Btn_Home.TabIndex = 7;
            Btn_Home.Text = "Home";
            Btn_Home.UseVisualStyleBackColor = false;
            Btn_Home.Click += Btn_Home_Click;
            // 
            // btn_formulario
            // 
            btn_formulario.BackColor = Color.FromArgb(255, 255, 128);
            btn_formulario.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            btn_formulario.Location = new Point(733, 645);
            btn_formulario.Name = "btn_formulario";
            btn_formulario.Size = new Size(260, 54);
            btn_formulario.TabIndex = 8;
            btn_formulario.Text = "Formulario";
            btn_formulario.UseVisualStyleBackColor = false;
            btn_formulario.Click += btn_formulario_Click;
            // 
            // Btn_ProximaObra
            // 
            Btn_ProximaObra.BackColor = Color.FromArgb(255, 255, 128);
            Btn_ProximaObra.Font = new Font("Arial", 24F, FontStyle.Bold | FontStyle.Underline, GraphicsUnit.Point, 0);
            Btn_ProximaObra.Location = new Point(999, 645);
            Btn_ProximaObra.Name = "Btn_ProximaObra";
            Btn_ProximaObra.Size = new Size(260, 54);
            Btn_ProximaObra.TabIndex = 9;
            Btn_ProximaObra.Text = "Proxima Obra";
            Btn_ProximaObra.UseVisualStyleBackColor = false;
            Btn_ProximaObra.Click += Btn_ProximaObra_Click;
            // 
            // MissaoApolo
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ActiveCaptionText;
            ClientSize = new Size(1284, 711);
            Controls.Add(Btn_ProximaObra);
            Controls.Add(btn_formulario);
            Controls.Add(Btn_Home);
            Controls.Add(Btn_voltarHome);
            Controls.Add(pictureBox1);
            Controls.Add(label1);
            Name = "MissaoApolo";
            Text = "Missao Apollo";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private PictureBox pictureBox1;
        private Button Btn_voltarHome;
        private Button Btn_Home;
        private Button btn_formulario;
        private Button Btn_ProximaObra;
    }
}