﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Museu_Pim.Modulos.CadastroList;

namespace Museu_Pim.Modulos
{
    public class CadastroList
    {
        private string Nome;
        private string Sobrenome;
        private int Idade11;
        private string Senha;

        public CadastroList(string Nome, string Sobrenome, int Idade11, string Senha)
        {
            this.Nome = Nome;
            this.Sobrenome = Sobrenome;
            this.Idade11 = Idade11;
            this.Senha = Senha;
        }

        public List<string> Nomes = new List<string>();
        public List<string> sobrenomes = new List<string>();
        public List<int> idades = new List<int>();
        public List<string> Senhas = new List<string>();

            public void cadastrarnome(string Nome)
            {
                Nomes.Add(Nome);
            }
     
            public void cadastrarsobrenome(string Sobrenome)
            {
                sobrenomes.Add(Sobrenome);
            }
        
            public void cadastaridade(int Idade11)
            {
                idades.Add(Idade11);
            }
       
            public void cadastarsenha(string Senha)
            {
                Senhas.Add(Senha);
            }
     
    }
}

