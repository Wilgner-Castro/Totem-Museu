﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace Museu_Pim.Modulos
{
    public class Validacao
    {
        private string nome;
        private string sobrenome;
        private string idade;
        private string senha;

        private string mensagem;
        private int Idade1;
        private string nomeLogin;
        private string senhaLogin;

        public string Nome { get => nome; }
        public string Sobrenome { get => sobrenome; }
        public string Senha { get => senha; }
        public int Idade11 { get => Idade1; }
        public string Mensagem { get => mensagem; }
        public bool Acesso { get; private set; }

        public Validacao(string nome, string sobrenome, string idade, string senha)
        {
            this.nome = nome;
            this.sobrenome = sobrenome;
            this.idade = idade;
            this.senha = senha;
            this.validar();
        }

        public Validacao(string nomeLogin, string senhaLogin)
        {
            this.nomeLogin = nomeLogin;
            this.senhaLogin = senhaLogin;
           
        }

        private void validar()
        {
            this.mensagem = "";
            try
            {
                this.Idade1 = Convert.ToInt32(this.idade);
                if (Regex.IsMatch(nome, @"^[a-zA-Z]*$")){}
                if (Regex.IsMatch(sobrenome, @"^[a-zA-Z]*$")) { }
                if (Regex.IsMatch(idade, @"^[0-9]*$")) { }
            
            }
            catch(Exception) {

                mensagem = "Digite informaçoes validas";
            }
        }

        public bool ValidarLogin(List<string> Nomes, List<string> Senhas, string nomeLogin, string senhaLogin)
        {
            // Verifique se o nome e a senha correspondem aos valores nas listas
            if (Nomes.Contains(nomeLogin) && Senhas.Contains(senhaLogin))
            {
                return Acesso = true; 
            }
            else
            {
                return Acesso = false;
            }
        }
    }
}

