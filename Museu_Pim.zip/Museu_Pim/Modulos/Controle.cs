﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Museu_Pim.Modulos
{
    public class Controle
    {
        private string nome;
        private string sobrenome;
        private string idade;
        private string senha;
        private string nomeLogin;
        private string senhaLogin;

        private string mensagem;
        public string Mensagem { get => mensagem; }

        public Controle(string nome, string sobrenome, string idade,string senha)
        {
            this.nome = nome;
            this.sobrenome = sobrenome;
            this.idade = idade;
            this.senha = senha;
            this.Executar();
        }

        public Controle(string nomeLogin, string senhaLogin)
        {
            this.nomeLogin = nomeLogin;
            this.senhaLogin = senhaLogin;
            this.ExecutarLogin();
        }

        private void Executar()
        {
            this.mensagem = "";
            Validacao validacao = new Validacao(this.nome, this.sobrenome, this.idade,this.senha);
            if (validacao.Mensagem.Equals(""))
            {
                CadastroList cadastrolist = new CadastroList(validacao.Nome, validacao.Sobrenome, validacao.Idade11,validacao.Senha);  

            }
            else
            {
                this.mensagem = validacao.Mensagem;
            }
        }
        private void ExecutarLogin()
        {
            this.mensagem = "";
            Validacao validacao = new Validacao(this.nomeLogin, this.senhaLogin);
            if (validacao.Acesso.Equals(true))
            {
                mensagem = "";
            }
            else
            {
                mensagem = "Informações não cadastradas";
            }
        
        }
    }
}
